<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Performance Chart</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <canvas id="performanceChart" width="400" height="200"></canvas>

    <script>
        
        const readTimes = {
            "Read completed tasks": 120,  
            "Read with read-only flag": 95,
            "Read with index": 70,
            "Read from new store": 60
        };

        
        const tasks = Object.keys(readTimes);
        const times = Object.values(readTimes);

        
        const ctx = document.getElementById('performanceChart').getContext('2d');
        const performanceChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: tasks,
                datasets: [{
                    label: 'Time (ms)',
                    data: times,
                    backgroundColor: 'rgba(54, 162, 235, 0.6)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                indexAxis: 'y',  // Horizontal bar chart
                scales: {
                    x: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Time (ms)'
                        }
                    }
                },
                plugins: {
                    title: {
                        display: true,
                        text: 'Performance Comparison of IndexedDB Operations'
                    }
                }
            }
        });
    </script>
</body>
</html>
