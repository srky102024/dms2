<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Roadmap Diagram</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f4f4f9;
        }
        .roadmap-container {
            text-align: center;
        }
        .step {
            background-color: #ffffff;
            padding: 10px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin: 10px;
            width: 180px;
            display: inline-block;
            position: relative;
        }
        .arrow {
            width: 40px;
            height: 10px;
            margin: 0 10px;
            display: inline-block;
            position: relative;
        }
        .arrow::before {
            content: "";
            width: 100%;
            height: 4px;
            background-color: #333;
            position: absolute;
            top: 50%;
            left: 0;
            transform: translateY(-50%);
        }
        .arrow::after {
            content: "";
            width: 0;
            height: 0;
            border-left: 10px solid #333;
            border-top: 5px solid transparent;
            border-bottom: 5px solid transparent;
            position: absolute;
            right: -10px;
            top: 50%;
            transform: translateY(-50%);
        }
    </style>
</head>
<body>

<div class="roadmap-container">
    <div class="step">1. Database Initialization</div>
    <div class="arrow"></div>
    <div class="step">2. Database Upgrade</div>
    <div class="arrow"></div>
    <div class="step">3. Data Population</div>
    <div class="arrow"></div>
    <div class="step">4. Read Completed Tasks</div>
    <div class="arrow"></div>
    <div class="step">5. Read In-Progress Tasks</div>
    <div class="arrow"></div>
    <div class="step">6. Update Graph</div>
</div>

</body>
</html>
