function simulateDatabaseOperations(numRecords) {
    const performanceMetrics = {};

    return new Promise((resolve) => {
        
        const startTime = Date.now();
        setTimeout(() => {
            performanceMetrics.dataPopulationTime = (Date.now() - startTime) / 1000; // Convert to seconds

            
            const startReading = Date.now();
            setTimeout(() => {
                performanceMetrics.readCompletedTasksTime = (Date.now() - startReading) / 1000;

                
                const startReadOnly = Date.now();
                setTimeout(() => {
                    performanceMetrics.readWithFlagTime = (Date.now() - startReadOnly) / 1000;

                    
                    const startIndex = Date.now();
                    setTimeout(() => {
                        performanceMetrics.indexCreationTime = (Date.now() - startIndex) / 1000;

                        
                        const startReadWithIndex = Date.now();
                        setTimeout(() => {
                            performanceMetrics.readWithIndexTime = (Date.now() - startReadWithIndex) / 1000;

                            
                            const startCopy = Date.now();
                            setTimeout(() => {
                                performanceMetrics.copyToNewStoreTime = (Date.now() - startCopy) / 1000;

                                
                                const startReadNewStore = Date.now();
                                setTimeout(() => {
                                    performanceMetrics.readFromNewStoreTime = (Date.now() - startReadNewStore) / 1000;

                                    
                                    resolve(performanceMetrics);
                                }, 40); 
                            }, 750); 
                        }, 50); 
                    }, 600); 
                }, 350); 
            }, 400); 
        }, 1000); 
    });
}


simulateDatabaseOperations(100000).then(performanceMetrics => {
    console.log(performanceMetrics);
});
