<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IndexedDB Todo List</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            max-width: 600px;
        }
        h1 {
            text-align: center;
        }
    </style>
</head>
<body>
    <h1>IndexedDB Todo List</h1>
    <p>Check the console for output.</p>

    <script>
        let db;

        const request = indexedDB.open("TodoDB", 1);

        request.onupgradeneeded = function(event) {
            db = event.target.result;
            let objectStore = db.createObjectStore("TodoList", { keyPath: "id", autoIncrement: true });
            objectStore.createIndex("status", "status", { unique: false });
            console.log("Object store and index created.");
        };

        request.onsuccess = function(event) {
            db = event.target.result;
            console.log("Database initialized.");
            populateData();
        };

        function populateData() {
            const transaction = db.transaction("TodoList", "readwrite");
            const objectStore = transaction.objectStore("TodoList");

            
            for (let i = 0; i < 100000; i++) {
                let task = {
                    task: `Task ${i}`,
                    status: i < 1000 ? "completed" : "in progress",
                    dueDate: new Date().toISOString().split('T')[0]
                };
                objectStore.add(task);
            }

            transaction.oncomplete = function() {
                console.log("Data populated.");
                measureReadTime();
            };
        }

        function measureReadTime() {
            const transaction = db.transaction("TodoList", "readonly");
            const objectStore = transaction.objectStore("TodoList");
            const index = objectStore.index("status");
            const startTime = performance.now();

            const request = index.openCursor(IDBKeyRange.only("completed"));
            request.onsuccess = function(event) {
                const cursor = event.target.result;
                if (cursor) {
                    cursor.continue();
                } else {
                    const endTime = performance.now();
                    console.log(`Time to read completed tasks: ${endTime - startTime} ms`);
                    applyReadOnlyFlag();
                }
            };
        }

        function applyReadOnlyFlag() {
            const transaction = db.transaction("TodoList", "readonly");
            const objectStore = transaction.objectStore("TodoList");
            const index = objectStore.index("status");
            const startTime = performance.now();

            const request = index.openCursor(IDBKeyRange.only("completed"));
            request.onsuccess = function(event) {
                const cursor = event.target.result;
                if (cursor) {
                    cursor.continue();
                } else {
                    const endTime = performance.now();
                    console.log(`Time to read completed tasks with read-only flag: ${endTime - startTime} ms`);
                    createCompletedIndex();
                }
            };
        }

        function createCompletedIndex() {
            const upgradeRequest = indexedDB.open("TodoDB", 2);
            
            upgradeRequest.onupgradeneeded = function(event) {
                db = event.target.result;
                let objectStore = db.transaction.objectStore("TodoList");
                objectStore.createIndex("status", "status", { unique: false });
                console.log("Index created.");
            };
            
            upgradeRequest.onsuccess = function(event) {
                db = event.target.result;
                measureIndexReadTime();
            };
        }

        function measureIndexReadTime() {
            const transaction = db.transaction("TodoList", "readonly");
            const objectStore = transaction.objectStore("TodoList");
            const index = objectStore.index("status");
            const startTime = performance.now();

            const request = index.openCursor(IDBKeyRange.only("completed"));
            request.onsuccess = function(event) {
                const cursor = event.target.result;
                if (cursor) {
                    cursor.continue();
                } else {
                    const endTime = performance.now();
                    console.log(`Time to read completed tasks with index: ${endTime - startTime} ms`);
                    createCompletedStore();
                }
            };
        }

        function createCompletedStore() {
            const transaction = db.transaction("TodoList", "readwrite");
            const objectStore = transaction.objectStore("TodoList");
            const completedStore = db.createObjectStore("TodoListCompleted", { keyPath: "id" });

            const cursorRequest = objectStore.openCursor(IDBKeyRange.only("completed"));
            cursorRequest.onsuccess = function(event) {
                const cursor = event.target.result;
                if (cursor) {
                    completedStore.add(cursor.value);
                    cursor.continue();
                } else {
                    const endTime = performance.now();
                    console.log(`Completed tasks copied to new store.`);
                    measureCompletedStoreReadTime();
                }
            };
        }

        function measureCompletedStoreReadTime() {
            const transaction = db.transaction("TodoListCompleted", "readonly");
            const objectStore = transaction.objectStore("TodoListCompleted");
            const startTime = performance.now();

            const request = objectStore.openCursor();
            request.onsuccess = function(event) {
                const cursor = event.target.result;
                if (cursor) {
                    cursor.continue();
                } else {
                    const endTime = performance.now();
                    console.log(`Time to read completed tasks from TodoListCompleted: ${endTime - startTime} ms`);
                }
            };
        }
    </script>
</body>
</html>
