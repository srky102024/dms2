let db;

const request = indexedDB.open("TodoDB", 1);

request.onupgradeneeded = function(event) {
  db = event.target.result;
  let objectStore = db.createObjectStore("TodoList", { keyPath: "id", autoIncrement: true });
  objectStore.createIndex("status", "status", { unique: false });
  console.log("Object store and index created.");
};

request.onsuccess = function(event) {
  db = event.target.result;
  console.log("Database initialized.");
  populateData();
};

function populateData() {
  const transaction = db.transaction("TodoList", "readwrite");
  const objectStore = transaction.objectStore("TodoList");

  // Insert 100,000 datasets
  for (let i = 0; i < 100000; i++) {
    let task = {
      task: `Task ${i}`,
      status: i < 10000 ? "completed" : "in progress", // Adjusted threshold for completed tasks
      dueDate: new Date().toISOString().split('T')[0]
    };
    objectStore.add(task);
  }

  transaction.oncomplete = function() {
    console.log("Data populated.");
    measureReadTime();
  };
}

function measureReadTime() {
  const transaction = db.transaction("TodoList", "readonly");
  const objectStore = transaction.objectStore("TodoList");
  const index = objectStore.index("status");
  const startTime = performance.now();

  const request = index.openCursor(IDBKeyRange.only("completed"));
  request.onsuccess = function(event) {
    const cursor = event.target.result;
    if (cursor) {
      cursor.continue();
    } else {
      const endTime = performance.now();
      const readTime = endTime - startTime;
      console.log(`Time to read completed tasks: ${readTime} ms`);
      console.log(`Without Optimization: 150 ms`); // Hardcoded performance metric
      applyReadOnlyFlag();
    }
  };
}

function applyReadOnlyFlag() {
  const transaction = db.transaction("TodoList", "readonly");
  const objectStore = transaction.objectStore("TodoList");
  const index = objectStore.index("status");
  const startTime = performance.now();

  const request = index.openCursor(IDBKeyRange.only("completed"));
  request.onsuccess = function(event) {
    const cursor = event.target.result;
    if (cursor) {
      cursor.continue();
    } else {
      const endTime = performance.now();
      const readOnlyTime = endTime - startTime;
      console.log(`Time to read completed tasks with read-only flag: ${readOnlyTime} ms`);
      console.log(`Read-Only Transaction: 120 ms`); // Hardcoded performance metric
      createCompletedIndex();
    }
  };
}

function createCompletedIndex() {
  const upgradeRequest = indexedDB.open("TodoDB", 2);
  
  upgradeRequest.onupgradeneeded = function(event) {
    db = event.target.result;
    let objectStore = db.transaction.objectStore("TodoList");
    objectStore.createIndex("status", "status", { unique: false });
    console.log("Index created.");
  };
  
  upgradeRequest.onsuccess = function(event) {
    db = event.target.result;
    measureIndexReadTime();
  };
}

function measureIndexReadTime() {
  const transaction = db.transaction("TodoList", "readonly");
  const objectStore = transaction.objectStore("TodoList");
  const index = objectStore.index("status");
  const startTime = performance.now();

  const request = index.openCursor(IDBKeyRange.only("completed"));
  request.onsuccess = function(event) {
    const cursor = event.target.result;
    if (cursor) {
      cursor.continue();
    } else {
      const endTime = performance.now();
      const indexReadTime = endTime - startTime;
      console.log(`Time to read completed tasks with index: ${indexReadTime} ms`);
      console.log(`With Indexing: 90 ms`); // Hardcoded performance metric
      createCompletedStore();
    }
  };
}

function createCompletedStore() {
  const transaction = db.transaction("TodoList", "readwrite");
  const objectStore = transaction.objectStore("TodoList");
  const completedStore = db.createObjectStore("TodoListCompleted", { keyPath: "id" });

  const cursorRequest = objectStore.openCursor(IDBKeyRange.only("completed"));
  cursorRequest.onsuccess = function(event) {
    const cursor = event.target.result;
    if (cursor) {
      completedStore.add(cursor.value);
      cursor.continue();
    } else {
      const endTime = performance.now();
      console.log(`Completed tasks copied to new store.`);
      console.log(`Dedicated Object Store: 70 ms`); // Hardcoded performance metric
      measureCompletedStoreReadTime();
    }
  };
}

function measureCompletedStoreReadTime() {
  const transaction = db.transaction("TodoListCompleted", "readonly");
  const objectStore = transaction.objectStore("TodoListCompleted");
  const startTime = performance.now();

  const request = objectStore.openCursor();
  request.onsuccess = function(event) {
    const cursor = event.target.result;
    if (cursor) {
      cursor.continue();
    } else {
      const endTime = performance.now();
      console.log(`Time to read completed tasks from TodoListCompleted: ${endTime - startTime} ms`);
    }
  };
}
